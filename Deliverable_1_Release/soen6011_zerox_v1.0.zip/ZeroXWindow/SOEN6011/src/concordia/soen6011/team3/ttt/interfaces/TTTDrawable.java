package concordia.soen6011.team3.ttt.interfaces;

import java.awt.Graphics2D;

/**
 * 
 * 
 * 
 * @author Team 3
 * @version 1.0
 */
public interface TTTDrawable {

	/**
	 * 
	 * @param graphics2d
	 */
	public void drawObject(Graphics2D graphics2d);

}
