package concordia.soen6011.team3.ttt.ui.images;

/**
 * 
 * @author Team 3
 * @version 1.0
 */
public class ImagePath {

	// Board Menu
	public final static String NEW_BOARD = "images/new_board_24_24.png";
	public final static String UNDO = "images/new_board_24_24.png";
	public final static String REDO = "images/new_board_24_24.png";

	// About Menu
	public final static String ABOUT_APP = "images/about_application_24_24.png";
	public final static String ABOUT_TEAM = "images/about_team_24_24.png";

}
